package com.example.kiran.test1;

import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class signup extends AppCompatActivity {

    public databasesqlhandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
   db = new databasesqlhandler(this);
        PrintUsers();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

    }

    private void PrintUsers() {
        List<infoUser> users = db.allUsers();

        if (users.size() == 0){
            System.out.println("No user found");
        }

        for ( int i = 0; i < users.size(); i++  ){
            System.out.println(users.toString());
        }
    }


    public void addUser(View view){
        EditText email   = (EditText)findViewById(R.id.email);
        EditText password   = (EditText)findViewById(R.id.password);

        if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
            Toast.makeText(this, "Fill all the fields!",
                    Toast.LENGTH_LONG).show();
        } else {

            infoUser newUser = new infoUser();
            newUser.setEmail(email.getText().toString());
            newUser.setPassword(password.getText().toString());
            System.out.println(newUser.toString());

            db.addUser(newUser);
        }

    }
}
